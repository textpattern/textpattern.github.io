Textpattern Logopack
--------------------

This is the official collection of Textpattern logos. There’s a wide variety of logos and
formats, so chances are good you’ll find one that fits your needs.

Have fun. Spread the word about Textpattern!


License
-------

This package is published as CareWare in the sense of
https://en.wikipedia.org/wiki/Careware
It’s our planet. Make it worth living here.
